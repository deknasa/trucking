/*
Stimulsoft.Reports.JS
Version: 2023.1.1
Build date: 2022.12.07
License: https://www.stimulsoft.com/en/licensing/reports
*/
export * from './stimulsoft.reports';
import {Stimulsoft} from './stimulsoft.reports';
export import StiViewer = Stimulsoft.Viewer.StiViewer;
export import StiViewerOptions = Stimulsoft.Viewer.StiViewerOptions;