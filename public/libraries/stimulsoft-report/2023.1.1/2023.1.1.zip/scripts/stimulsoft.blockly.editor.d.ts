/*
Stimulsoft.Reports.JS
Version: 2023.1.1
Build date: 2022.12.07
License: https://www.stimulsoft.com/en/licensing/reports
*/
export * from './stimulsoft.designer';