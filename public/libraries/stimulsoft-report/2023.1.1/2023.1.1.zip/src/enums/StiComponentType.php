<?php

namespace Stimulsoft\Enums;

class StiComponentType
{
    const Report = 'Report';
    const Viewer = 'Viewer';
    const Designer = 'Designer';
}