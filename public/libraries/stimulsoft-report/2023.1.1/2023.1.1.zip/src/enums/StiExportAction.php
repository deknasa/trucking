<?php

namespace Stimulsoft\Enums;

class StiExportAction
{
    const ExportReport = 1;
    const SendEmail = 2;
    const PrintReport = 3;
}