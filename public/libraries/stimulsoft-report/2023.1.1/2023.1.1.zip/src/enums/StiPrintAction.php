<?php

namespace Stimulsoft\Enums;

class StiPrintAction
{
    const PrintPdf = 'PrintPdf';
    const PrintWithoutPreview = 'PrintWithoutPreview';
    const PrintWithPreview = 'PrintWithPreview';
}