<?php

namespace Stimulsoft\Report\Enums;

class StiHtmlExportMode
{
    const Span = 'Stimulsoft.Report.Export.StiHtmlExportMode.Span';
    const Div = 'Stimulsoft.Report.Export.StiHtmlExportMode.Div';
    const Table = 'Stimulsoft.Report.Export.StiHtmlExportMode.Table';
    const FromReport = 'Stimulsoft.Report.Export.StiHtmlExportMode.FromReport';
}