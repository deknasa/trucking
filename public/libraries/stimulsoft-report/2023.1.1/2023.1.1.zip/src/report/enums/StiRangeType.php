<?php

namespace Stimulsoft\Report\Enums;

class StiRangeType
{
    const All = 'Stimulsoft.Report.StiRangeType.All';
    const CurrentPage = 'Stimulsoft.Report.StiRangeType.CurrentPage';
    const Pages = 'Stimulsoft.Report.StiRangeType.Pages';
}