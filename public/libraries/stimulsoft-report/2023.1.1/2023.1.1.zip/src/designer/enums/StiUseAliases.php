<?php

namespace Stimulsoft\Designer\Enums;

class StiUseAliases
{
    const Auto = 'Stimulsoft.Designer.StiUseAliases.Auto';
    const True = 'Stimulsoft.Designer.StiUseAliases.True';
    const False = 'Stimulsoft.Designer.StiUseAliases.False';
}