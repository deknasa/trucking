<?php

namespace Stimulsoft\Designer\Enums;

class StiFirstDayOfWeek
{
    const Auto = 'Stimulsoft.Designer.StiFirstDayOfWeek.Auto';
    const Monday = 'Stimulsoft.Designer.StiFirstDayOfWeek.Monday';
    const Sunday = 'Stimulsoft.Designer.StiFirstDayOfWeek.Sunday';
}