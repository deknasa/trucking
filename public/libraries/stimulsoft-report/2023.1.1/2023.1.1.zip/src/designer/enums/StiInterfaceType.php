<?php

namespace Stimulsoft\Designer\Enums;

class StiInterfaceType
{
    const Auto = 'Stimulsoft.Designer.StiInterfaceType.Auto';
    const Mouse = 'Stimulsoft.Designer.StiInterfaceType.Mouse';
    const Touch = 'Stimulsoft.Designer.StiInterfaceType.Touch';
}