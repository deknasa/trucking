<?php

namespace Stimulsoft\Designer\Enums;

class StiPropertiesGridPosition
{
    const Left = 'Stimulsoft.Designer.StiPropertiesGridPosition.Left';
    const Right = 'Stimulsoft.Designer.StiPropertiesGridPosition.Right';
}