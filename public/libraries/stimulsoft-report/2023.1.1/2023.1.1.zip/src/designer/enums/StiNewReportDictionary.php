<?php

namespace Stimulsoft\Designer\Enums;

class StiNewReportDictionary
{
    const Auto = 'Stimulsoft.Designer.StiNewReportDictionary.Auto';
    const DictionaryNew = 'Stimulsoft.Designer.StiNewReportDictionary.DictionaryNew';
    const DictionaryMerge = 'Stimulsoft.Designer.StiNewReportDictionary.DictionaryMerge';
}