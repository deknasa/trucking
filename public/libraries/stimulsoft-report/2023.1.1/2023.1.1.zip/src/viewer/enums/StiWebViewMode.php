<?php

namespace Stimulsoft\Viewer\Enums;

class StiWebViewMode
{
    const SinglePage = 'Stimulsoft.Viewer.StiWebViewMode.SinglePage';
    const Continuous = 'Stimulsoft.Viewer.StiWebViewMode.Continuous';
    const MultiplePages = 'Stimulsoft.Viewer.StiWebViewMode.MultiplePages';
}