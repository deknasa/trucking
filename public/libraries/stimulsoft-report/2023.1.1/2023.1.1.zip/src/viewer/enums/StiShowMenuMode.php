<?php

namespace Stimulsoft\Viewer\Enums;

class StiShowMenuMode
{
    const Click = 'Stimulsoft.Viewer.StiShowMenuMode.Click';
    const Hover = 'Stimulsoft.Viewer.StiShowMenuMode.Hover';
}