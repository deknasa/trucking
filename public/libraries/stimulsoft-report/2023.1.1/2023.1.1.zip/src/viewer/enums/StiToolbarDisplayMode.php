<?php

namespace Stimulsoft\Viewer\Enums;

class StiToolbarDisplayMode
{
    const Simple = 'Stimulsoft.Viewer.StiToolbarDisplayMode.Simple';
    const Separated = 'Stimulsoft.Viewer.StiToolbarDisplayMode.Separated';
}