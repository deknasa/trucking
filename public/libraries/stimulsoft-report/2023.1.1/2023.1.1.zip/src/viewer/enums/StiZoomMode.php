<?php

namespace Stimulsoft\Viewer\Enums;

class StiZoomMode
{
    const PageWidth = 'Stimulsoft.Viewer.StiZoomMode.PageWidth';
    const PageHeight = 'Stimulsoft.Viewer.StiZoomMode.PageHeight';
}