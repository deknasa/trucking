<?php

namespace Stimulsoft\Viewer\Enums;

class StiFirstDayOfWeek
{
    const Auto = 'Stimulsoft.Viewer.StiFirstDayOfWeek.Auto';
    const Monday = 'Stimulsoft.Viewer.StiFirstDayOfWeek.Monday';
    const Sunday = 'Stimulsoft.Viewer.StiFirstDayOfWeek.Sunday';
}