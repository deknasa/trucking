<?php

namespace Stimulsoft\Viewer\Enums;

class StiContentAlignment
{
    const Left = 'Stimulsoft.Viewer.StiContentAlignment.Left';
    const Center = 'Stimulsoft.Viewer.StiContentAlignment.Center';
    const Right = 'Stimulsoft.Viewer.StiContentAlignment.Right';
    const DefaultValue = 'Stimulsoft.Viewer.StiContentAlignment.Default';
}