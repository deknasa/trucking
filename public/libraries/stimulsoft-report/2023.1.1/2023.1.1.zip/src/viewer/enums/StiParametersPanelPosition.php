<?php

namespace Stimulsoft\Viewer\Enums;

class StiParametersPanelPosition
{
    const Top = 'Stimulsoft.Viewer.StiParametersPanelPosition.Top';
    const Left = 'Stimulsoft.Viewer.StiParametersPanelPosition.Left';
    const FromReport = 'Stimulsoft.Viewer.StiParametersPanelPosition.FromReport';
}