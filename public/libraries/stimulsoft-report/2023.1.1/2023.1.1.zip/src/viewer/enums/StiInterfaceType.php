<?php

namespace Stimulsoft\Viewer\Enums;

class StiInterfaceType
{
    const Auto = 'Stimulsoft.Viewer.StiInterfaceType.Auto';
    const Mouse = 'Stimulsoft.Viewer.StiInterfaceType.Mouse';
    const Touch = 'Stimulsoft.Viewer.StiInterfaceType.Touch';
    const Mobile = 'Stimulsoft.Viewer.StiInterfaceType.Mobile';
}