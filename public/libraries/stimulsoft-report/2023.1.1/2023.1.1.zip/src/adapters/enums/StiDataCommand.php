<?php

namespace Stimulsoft\Enums;

class StiDataCommand
{
    const GetSupportedAdapters = 'GetSupportedAdapters';
    const TestConnection = 'TestConnection';
    const ExecuteQuery = 'ExecuteQuery';
}