<?php

namespace Stimulsoft;

class StiJavaScriptOptions
{
    public $reports = true;
    public $reportsChart = true;
    public $reportsExport = true;
    public $reportsImportXlsx = true;
    public $reportsMaps = true;
    public $blocklyEditor = true;
}