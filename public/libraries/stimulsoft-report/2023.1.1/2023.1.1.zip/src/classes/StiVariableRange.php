<?php

namespace Stimulsoft;

class StiVariableRange
{
    public $from;
    public $to;
}