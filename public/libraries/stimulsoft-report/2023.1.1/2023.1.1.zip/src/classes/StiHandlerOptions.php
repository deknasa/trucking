<?php

namespace Stimulsoft;

class StiHandlerOptions
{
    public $url = 'handler.php';
    public $timeout = 30;
}